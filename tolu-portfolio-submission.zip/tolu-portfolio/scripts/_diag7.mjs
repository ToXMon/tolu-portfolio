import { chromium } from 'playwright';
const browser = await chromium.launch();
const ctx = await browser.newContext({ viewport: { width: 1440, height: 900 } });
const page = await ctx.newPage();
page.on('console', m => console.log(`[${m.type()}] ${m.text()}`));
await page.goto('http://localhost:8080/', { waitUntil: 'networkidle' });
await page.waitForTimeout(800);
await page.evaluate(() => window.toluOS.openProjectWindow('music'));
await page.waitForTimeout(100);
await page.evaluate(() => document.querySelector('.audio-transport [data-act="play"]').click());
// Wait for the audio to load
await page.waitForTimeout(8000);
const audioState = await page.evaluate(() => {
  // Find any audio element via getter on MusicApp
  const aels = Array.from(document.querySelectorAll('audio'));
  return {
    audiosFound: aels.length,
    internalAudioSrc: (() => {
      // MusicApp stores its Audio in a closure. Try to find via state.
      try {
        return MusicApp.state.track ? MusicApp.state.track.streamUrl.slice(0, 80) : null;
      } catch { return null; }
    })(),
    state: {
      playing: MusicApp.state.playing,
      index: MusicApp.state.index,
      trackTitle: MusicApp.state.track ? MusicApp.state.track.title : null,
      pendingPlay: MusicApp.state.pendingPlay,
      beat: MusicApp.state.beatEnergy
    }
  };
});
console.log('AUDIO:', JSON.stringify(audioState, null, 2));
await browser.close();
